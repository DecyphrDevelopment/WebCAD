﻿using Newtonsoft.Json;

namespace JSONReader
{
    class User
    {
        [JsonProperty("username")]
        public string Username { get; set; }

        [JsonProperty("password")]
        public string Password { get; set; }

        [JsonProperty("uuid")]
        public string UUID { get; set; }

        [JsonProperty("level")]
        public int Level { get; set; }

        [JsonProperty("terms_accepted")]
        public int TermsStatus { get; set; }

        [JsonProperty("last_ip")]
        public string LastIP { get; set; }
    }
}