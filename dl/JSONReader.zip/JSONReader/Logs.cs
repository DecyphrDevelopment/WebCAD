﻿using Newtonsoft.Json;

namespace JSONReader
{
    class Log
    {
        [JsonProperty("id")]
        public int ID { get; set; }

        [JsonProperty("user")]
        public string User { get; set; }

        [JsonProperty("ip")]
        public string IP { get; set; }

        [JsonProperty("action")]
        public string Action { get; set; }

        [JsonProperty("timestamp")]
        public string Timestamp { get; set; }
    }
}