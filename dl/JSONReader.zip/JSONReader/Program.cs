﻿using System;
using System.Collections.Generic;
using System.Net;
using ConsoleUtils.Logging;
using ConsoleUtils.Writing;
using Newtonsoft.Json;
using System.Threading;

namespace JSONReader
{
    class Program
    {
        static InitWriterLogger wl = new InitWriterLogger();
        static int initialLogLength = 0;
        static void Main(string[] args)
        {
            //Uncomment what you want to do. Only have 1 uncommented at a time.
            ShowTermAccptedUsers();
            //StartLogMonitor();
        }

        private static void ShowTermAccptedUsers()
        {
            WebClient wc = new WebClient();
            //I also zipped the PHP file so you can see what it looks like.
            var json = wc.DownloadString("http://afs.lunarwebsite.ca/cad/scripts/jsonreader.php?users=yes");

            List<User> users = JsonConvert.DeserializeObject<List<User>>(json);

            foreach (User user in users)
            {
                if (user.TermsStatus == 1)
                {
                    wl.writer.Log("Username: " + user.Username);
                    wl.writer.Log("UUID: " + user.UUID);
                    wl.writer.Log("Level: " + user.Level);
                    wl.writer.Log("Terms Accepted?: " + user.TermsStatus);
                    wl.writer.Log("Last IP: " + user.LastIP);
                }
            }
            wl.writer.Wait();
        }

        private static void StartLogMonitor()
        {
            WebClient wc = new WebClient();
            //I also zipped the PHP file so you can see what it looks like.
            var json = wc.DownloadString("http://afs.lunarwebsite.ca/cad/scripts/jsonreader.php?logs=yes");

            List<Log> logs = JsonConvert.DeserializeObject<List<Log>>(json);
            initialLogLength = logs.Count;
            foreach (Log log in logs)
            {
                wl.writer.Custom(log.Timestamp + " -  |  - " + log.User + " -  |  - " + log.IP + " -  |  - " + log.Action, Color.Gray);
            }
            Timer t = new Timer(TimerCallback, null, 0, 2000);
            Console.ReadLine();
        }

        private static void TimerCallback(object o)
        {
            WebClient wc = new WebClient();
            //I also zipped the PHP file so you can see what it looks like.
            var json = wc.DownloadString("http://afs.lunarwebsite.ca/cad/scripts/jsonreader.php?logs=yes");

            List<Log> logs = JsonConvert.DeserializeObject<List<Log>>(json);
            if (logs.Count > initialLogLength)
            {
                initialLogLength = logs.Count;
                Log log = logs[initialLogLength - 1];
                wl.writer.Custom(log.Timestamp + " -  |  - " + log.User + " -  |  - " + log.IP + " -  |  - " + log.Action, Color.Gray);
            }
            GC.Collect();
        }
    }
}
